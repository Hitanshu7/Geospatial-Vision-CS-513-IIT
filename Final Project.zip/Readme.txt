To run the Project

script.py
	python script.py <point_cloud_data_file> <camera_config_file>


For example:
	python script.py ./final_project_data/final_project_point_cloud.fuse ./final_project_data/image/camera.config