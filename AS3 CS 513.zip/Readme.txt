HW3.py:
    python HW3.py <lat1,lon1,lat2,lon2>(no space)

    lat1,lon1,lat2,lon2: 
        -the longitude and latitude of the bounding box.

        -left top corner:lat1,lon1
        
        -right bottom corner: lat2,lon2

Example:
    python HW3.py 41.839468,-87.629517,41.831192,-87.623510

    
